package com.examples.inspire;

public class Defaults
{
  
public static final String APPLICATION_ID = "1C0DA01D-01F8-CC77-FF89-629A70D7CB00";
public static final String API_KEY = "D5242878-29DD-0377-FF39-FC1E91E64300";
public static final String SERVER_URL = "https://api.backendless.com";
    
}
                                            